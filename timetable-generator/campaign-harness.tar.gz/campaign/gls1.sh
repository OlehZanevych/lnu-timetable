#!/usr/bin/env bash
# T2.1 / G1 — guided local search on the residual.
#
# The one idea in the catalogue aimed at what §3.2 *proved* rather than at what the search does. The
# residual is a strict local optimum **of the objective**: an exact day-slice solver enumerated
# 46 656 complete arrangements per defect and returned `best == before`, because closing one lecturer
# window is worth β₇(26²−25²) = 255 and the group window that closing it opens costs β₈(12²−11²) =
# 460. Every mechanism this campaign has tried attacked the search. This one changes the surface:
# while stuck, `cost()` carries `λ · Σ_{b ∈ P} windows(b)` over the buckets holding the current
# residual, so the configuration the search keeps re-creating stops being the cheapest thing nearby.
#
# Measured on tight-XL at two workers and 180 s, which is exactly where §6q found the search sitting
# at the equilibrium with nothing left to descend — the regime where every throughput idea measured
# null. If GLS is null *here* too, the equilibrium is not reachable by re-shaping the surface either,
# and that is worth knowing as sharply as a win would be.
#
# λ in units of β₇ = 5: the spec suggests 0.5–2×, so 2.5 / 5 / 10.
#
# Two things to watch besides quality. `glsArmings` must be non-zero — a run where the penalty never
# armed did not test anything. And feasibility must not regress: a penalty big enough to move the
# endgame is big enough to distort the descent that reaches it, so any run with hard > 0 kills the
# rung whatever it does to the windows.
set -u
cd "$(dirname "$0")/.."

log() { printf '[%s] %s\n' "$(date -u +%H:%M:%S)" "$*"; }

INST="bench/instances-tight-xl/n12800-s1.json.gz bench/instances-tight-xl/n12800-s2.json.gz bench/instances-tight-xl/n12800-s3.json.gz"

log "G1-A: the lambda ladder, tight-XL, two workers, 180 s"
node campaign/exp.mjs --exp G1-gls --stage A --time 180000 --threads 2 --par 1 \
  --bin build/ts-J --seeds "11 22 33 44 55 66" --instances "$INST" \
  --arm "off:" \
  --arm "gls2:--gls 2.5" \
  --arm "gls5:--gls 5" \
  --arm "gls10:--gls 10" \
  --out bench/results/G1-A.jsonl 2>&1 | tail -3

log "G1 done"
