#!/usr/bin/env bash
# The K block: build the room-scan flags, prove the new scan path is still correct, then measure the
# two mechanisms the J2 curve leaves open — sample size (K1, diagnostic) and travel pricing
# (K2, a candidate fix). Run after J2 releases the cores.
set -u
cd "$(dirname "$0")/.."

log() { printf '[%s] %s\n' "$(date -u +%H:%M:%S)" "$*"; }

log "build"
cmake --build build --target timetable-solve -j2 2>&1 | tail -5 || exit 1
# Snapshot the binary, as every block does, so these results stay reproducible after later edits.
cp build/timetable-solve build/ts-G || exit 1

log "smoke: new scan path, 60 s on n=3200, must reach hard=0 and pass the validator"
SMOKE=bench/instances-tight/n03200-s1.json.gz
node campaign/exp.mjs --exp K0-smoke --stage S --time 60000 --threads 1 --par 2 \
  --bin build/ts-G --seeds "11" --instances "$SMOKE" \
  --arm "off:" --arm "bf:--room-building-first" \
  --out bench/results/K0-smoke.jsonl 2>&1 | tail -5

# K2 first: it is the candidate improvement. Three levels of the J2 ladder — the shipped-like end,
# the middle, and the pure end — so that any effect can be read against the curve it is meant to
# explain.
log "K1-A: the room-sample ladder, 180 s, where the effect is strongest"
node campaign/exp.mjs --exp K1-sample --stage A --time 180000 --threads 1 --par 2 \
  --bin build/ts-G --seeds "11 22 33" \
  --instances "bench/instances-unres/uni-ur060-n12800-s1.json.gz bench/instances-unres/uni-ur060-n12800-s2.json.gz bench/instances-unres/uni-ur060-n12800-s3.json.gz bench/instances-unres/uni-ur10-n12800-s1.json.gz bench/instances-unres/uni-ur10-n12800-s2.json.gz bench/instances-unres/uni-ur10-n12800-s3.json.gz" \
  --arm "s24:--room-sample 24" --arm "off:" --arm "s256:--room-sample 256" \
  --arm "full:--room-scan-full-below 1024" \
  --out bench/results/K1-A.jsonl 2>&1 | tail -3

log "K2-A: --room-building-first, 180 s screen"
node campaign/exp.mjs --exp K2-buildfirst --stage A --time 180000 --threads 1 --par 2 \
  --bin build/ts-G --seeds "11 22 33" \
  --instances "bench/instances-unres/uni-ur0-n12800-s1.json.gz bench/instances-unres/uni-ur0-n12800-s2.json.gz bench/instances-unres/uni-ur0-n12800-s3.json.gz bench/instances-unres/uni-ur035-n12800-s1.json.gz bench/instances-unres/uni-ur035-n12800-s2.json.gz bench/instances-unres/uni-ur035-n12800-s3.json.gz bench/instances-unres/uni-ur10-n12800-s1.json.gz bench/instances-unres/uni-ur10-n12800-s2.json.gz bench/instances-unres/uni-ur10-n12800-s3.json.gz" \
  --arm "off:" --arm "bf:--room-building-first" \
  --out bench/results/K2-A.jsonl 2>&1 | tail -3

log "K block done"
