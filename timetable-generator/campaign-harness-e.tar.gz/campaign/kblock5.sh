#!/usr/bin/env bash
# E10 — the sample ladder, re-run on top of the cheap scan.
#
# Two results have to be combined and neither predicts the answer on its own.
#
#   K1 (§6l) found the sample is a throughput trade and that 24 beats the shipped 96, monotonically,
#            because every room examined cost an O(bucket) walk.
#   E7/E8    removed those walks. The cost curve the ladder was climbing is not the same curve.
#
# So the optimum sample size has to be re-found, and it should move *up*: looking is cheaper now, so
# more of it should be affordable. If it does not move up, looking was never the whole story.
#
# Three arms and six seeds rather than five arms and three, deliberately, and only the two levels
# where the effect lives. The quality effects on this set are running at a
# variance that six paired seeds cannot resolve — E8 gave W/L 8/3 and a mean of the *wrong sign* on
# the same eleven pairs — so the budget is better spent on pairs than on rungs. Throughput is the
# claim these arms establish cleanly; quality is decided by E11 on the shipped sets.
set -u
cd "$(dirname "$0")/.."

log() { printf '[%s] %s\n' "$(date -u +%H:%M:%S)" "$*"; }

FAST="--hoist-day-caps --cap-cache --room-free-mask 2"
INST="bench/instances-unres/uni-ur060-n12800-s1.json.gz bench/instances-unres/uni-ur060-n12800-s2.json.gz bench/instances-unres/uni-ur060-n12800-s3.json.gz bench/instances-unres/uni-ur10-n12800-s1.json.gz bench/instances-unres/uni-ur10-n12800-s2.json.gz bench/instances-unres/uni-ur10-n12800-s3.json.gz"

log "E10-A: the sample ladder on the cheap scan"
node campaign/exp.mjs --exp E10-ladder --stage A --time 180000 --threads 1 --par 2 \
  --bin build/ts-I --seeds "11 22 33 44 55 66" --instances "$INST" \
  --arm "s24:--room-sample 24" \
  --arm "f24:$FAST --room-sample 24" \
  --arm "f48:$FAST --room-sample 48" \
  --out bench/results/E10-A.jsonl 2>&1 | tail -3

log "E10 done"
