#!/usr/bin/env node
// The budget ladder, read off the trajectories of long runs rather than from separate series.
//
// Single-worker runs have the anytime property (ALGORITHM.md §3.9): nothing in the search consumes
// the *remaining* budget, so the incumbent at time t of an hour-long run is distributed exactly as
// the final incumbent of a t-long run at the same seed. One hour per (arm, seed) therefore yields
// the whole ladder — and, unlike a ladder of separate runs, every rung is paired.
import { readdirSync, readFileSync } from 'node:fs';
const dir = process.argv[2] ?? 'logs/traj';
const marks = (process.argv[3] ?? '60 300 900 1800 3600').split(/\s+/).map(Number);
const table = new Map();
for (const f of readdirSync(dir).filter(x => x.endsWith('.csv'))) {
  const m = f.match(/-([^-]+)-(\d+)\.csv$/);
  if (!m) continue;
  const [, arm, seed] = m;
  const lines = readFileSync(`${dir}/${f}`, 'utf8').trim().split('\n');
  const head = lines[0].split(',');
  const iS = head.indexOf('seconds'), iSoft = head.indexOf('runBestSoft'), iObj = head.indexOf('runBestObjective');
  const out = new Array(marks.length).fill(null);
  let k = 0;
  for (const line of lines.slice(1)) {
    const c = line.split(',');
    const t = Number(c[iS]);
    while (k < marks.length && t >= marks[k]) { out[k] = [Number(c[iSoft]), Number(c[iObj])]; k++; }
  }
  const last = lines[lines.length - 1].split(',');
  for (let q = k; q < marks.length; q++) out[q] = [Number(last[iSoft]), Number(last[iObj])];
  if (!table.has(arm)) table.set(arm, new Map());
  table.get(arm).set(seed, out);
}
const arms = [...table.keys()].sort();
const seeds = [...new Set(arms.flatMap(a => [...table.get(a).keys()]))].sort();
console.log('budget'.padEnd(8) + arms.map(a => a.padStart(22)).join(''));
for (let q = 0; q < marks.length; q++) {
  const cells = arms.map(a => {
    const vals = seeds.map(s => table.get(a).get(s)?.[q]?.[0]).filter(v => v != null);
    if (!vals.length) return '—'.padStart(22);
    const sorted = [...vals].sort((x, y) => x - y);
    const med = sorted.length % 2 ? sorted[sorted.length >> 1]
                                  : (sorted[(sorted.length >> 1) - 1] + sorted[sorted.length >> 1]) / 2;
    return `${vals.join('/')} med ${med}`.padStart(22);
  });
  console.log(`${marks[q]}s`.padEnd(8) + cells.join(''));
}
// paired differences at each rung
if (arms.length === 2) {
  console.log('\npaired Δsoft (second arm − first), by seed:');
  for (let q = 0; q < marks.length; q++) {
    const d = seeds.map(s => {
      const a = table.get(arms[0]).get(s)?.[q]?.[0], b = table.get(arms[1]).get(s)?.[q]?.[0];
      return (a == null || b == null) ? null : b - a;
    }).filter(v => v != null);
    if (!d.length) continue;
    const wins = d.filter(x => x < 0).length, losses = d.filter(x => x > 0).length;
    console.log(`  ${String(marks[q]).padStart(5)}s  ${d.map(x => (x > 0 ? '+' : '') + x).join(' ')}` +
                `   mean ${(d.reduce((x, y) => x + y, 0) / d.length).toFixed(2)}  W/L ${wins}/${losses}`);
  }
}
