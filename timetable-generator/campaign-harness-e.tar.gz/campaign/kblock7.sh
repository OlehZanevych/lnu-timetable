#!/usr/bin/env bash
# E12 — the budget check, which is where this campaign's results have gone to die before.
#
# The pattern is documented and it has caught three separate mechanisms: an effect measured at a
# short budget on a single worker shrinks or reverses at a long budget on two. `--soft-alpha 1
# --soft-equal` went −19.1 % at 300 s single-worker to **+2.1 %** at 900 s two workers (§6c.1);
# `--flat-phase` went −8 % at six seeds to null at twenty (§6b); the coupling effect halved between
# three seeds and six (§6f). Nothing measured on this branch has been through that filter yet.
#
# The mechanism here gives some reason to expect it to survive — more candidates per second is not a
# quantity that stops mattering, and unlike the objective-shape result it does not redistribute
# anything — but that was also a plausible argument in each of the three cases above.
#
# Measured on `instances-unres` rather than on tight-XL, because E11 has now answered the tight-XL
# question and answered it null (9/8, 9/8, 9/7 across three arms and eighteen pairs, with candidate
# rates up 20–43 %). Re-running a null at three times the budget would confirm something already
# known. The open question is the other one: does the *win* survive the filter, or does it follow
# §6c.1 and evaporate at a longer budget on two workers?
#
# Two arms only. At 900 s each run costs a quarter-hour, so the budget buys pairs, and pairs are what
# the previous sections kept turning out to need.
set -u
cd "$(dirname "$0")/.."

log() { printf '[%s] %s\n' "$(date -u +%H:%M:%S)" "$*"; }

FAST="--hoist-day-caps --cap-cache --room-free-mask 2 --room-sample 24"
INST="bench/instances-unres/uni-ur060-n12800-s1.json.gz bench/instances-unres/uni-ur060-n12800-s2.json.gz bench/instances-unres/uni-ur060-n12800-s3.json.gz bench/instances-unres/uni-ur10-n12800-s1.json.gz bench/instances-unres/uni-ur10-n12800-s2.json.gz bench/instances-unres/uni-ur10-n12800-s3.json.gz"

log "E12-C: 900 s, two workers, the set where the effect lives"
node campaign/exp.mjs --exp E12-budget --stage C --time 900000 --threads 2 --par 1 \
  --bin build/ts-I --seeds "11 22 33" --instances "$INST" \
  --arm "off:" --arm "fast24:$FAST" \
  --out bench/results/E12-C.jsonl 2>&1 | tail -3

log "E12 done"
