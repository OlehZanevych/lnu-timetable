#!/usr/bin/env bash
# E7 — the room-occupancy mask, and the question K1 raised.
#
# K1-A found the room sample to be a pure throughput trade: 24 rooms beat the shipped 96, 256 was
# worse, and scanning the whole domain was catastrophic. Every rung of that ladder costs what it
# costs for one reason — `roomClashesAt` walks the room's day, so pricing a room is O(the room's
# day) and a 582-room domain is 582 walks.
#
# Room buckets now carry the same occupancy masks the people families always had, so "is this room
# free?" is one AND. If scan cost is the whole story, the ladder should inverte: with the mask, the
# *full* scan should become affordable and should win, because coverage was never the problem —
# paying for coverage was.
#
#   verify  `--room-free-mask 3` answers from the walk and checks the mask against it on every query.
#           Zero mismatches over a whole run is what licenses everything below.
#   rfm1    mask fast path, behaviour-identical, walk only for busy rooms.
#   rfm2    mask only, one clash charged for any busy room, no walk ever.
#   rfm2f   rfm2 with the sampling removed — the arm this was all for.
#   s24     K1-A's winner, as the bar to beat.
set -u
cd "$(dirname "$0")/.."

log() { printf '[%s] %s\n' "$(date -u +%H:%M:%S)" "$*"; }

log "build"
cmake --build build --target timetable-solve -j2 2>&1 | tail -3 || exit 1
cp build/timetable-solve build/ts-H || exit 1

log "E7 verification: the mask against the walk, every query, three instances"
for I in uni-ur0-n12800-s1 uni-ur060-n12800-s1 uni-ur10-n12800-s1; do
  build/ts-H --instance "bench/instances-unres/$I.json.gz" --time 60000 --threads 2 --seed 11 \
    --room-free-mask 3 --quiet --out /tmp/verify-$I.json > /tmp/verify-$I.stats.json 2>&1
  node -e '
    const fs=require("fs");const f=process.argv[1];
    let j; try { j=JSON.parse(fs.readFileSync(f,"utf8")); } catch(e){ console.log(f,"UNPARSEABLE"); process.exit(0); }
    const w=j.workers||[];
    const c=w.reduce((a,x)=>a+(x.roomMaskChecks||0),0), m=w.reduce((a,x)=>a+(x.roomMaskMismatch||0),0);
    console.log(process.argv[2], "checks="+c, "mismatch="+m, m===0&&c>0?"OK":"*** FAIL ***");
  ' /tmp/verify-$I.stats.json "$I"
done

INST="bench/instances-unres/uni-ur0-n12800-s1.json.gz bench/instances-unres/uni-ur0-n12800-s2.json.gz bench/instances-unres/uni-ur0-n12800-s3.json.gz bench/instances-unres/uni-ur060-n12800-s1.json.gz bench/instances-unres/uni-ur060-n12800-s2.json.gz bench/instances-unres/uni-ur060-n12800-s3.json.gz bench/instances-unres/uni-ur10-n12800-s1.json.gz bench/instances-unres/uni-ur10-n12800-s2.json.gz bench/instances-unres/uni-ur10-n12800-s3.json.gz"

log "E7-A: the mask ladder"
node campaign/exp.mjs --exp E7-roommask --stage A --time 180000 --threads 1 --par 2 \
  --bin build/ts-H --seeds "11 22 33" --instances "$INST" \
  --arm "off:" \
  --arm "s24:--room-sample 24" \
  --arm "rfm1:--room-free-mask 1" \
  --arm "rfm2:--room-free-mask 2" \
  --arm "rfm2f:--room-free-mask 2 --room-scan-full-below 1024" \
  --out bench/results/E7-A.jsonl 2>&1 | tail -3

log "E7 done"
