#!/usr/bin/env node
// The campaign driver: runs a matrix of (arm × seed × instance) at one budget, scores every run
// with the INDEPENDENT validator, and appends one JSON line per run to a results file.
//
//   node campaign/exp.mjs --exp E1-regret --stage A --time 60000 --threads 1 --par 2 \
//        --seeds "11 22 33 44 55 66" --instances "a.json.gz b.json.gz" \
//        --arm "off:" --arm "regret:--regret 2" --out bench/results/E1-A.jsonl
import { execFile } from 'node:child_process';
import { appendFileSync, mkdirSync, readFileSync, existsSync } from 'node:fs';
import { dirname, basename } from 'node:path';
import { gunzipSync } from 'node:zlib';
import { validate } from '../../timetable-ui/scripts/timetable-bench/validate.mjs';

const argv = {}; const arms = [];
for (let i = 2; i < process.argv.length; i++) {
  const a = process.argv[i];
  if (!a.startsWith('--')) continue;
  const key = a.slice(2);
  const nx = process.argv[i + 1];
  const val = nx && !nx.startsWith('--') ? (i++, nx) : true;
  if (key === 'arm') arms.push(val); else argv[key] = val;
}
const exp = argv.exp ?? 'adhoc', stage = argv.stage ?? '?';
const timeMs = Number(argv.time ?? 60000), threads = Number(argv.threads ?? 1);
const par = Number(argv.par ?? 2);
const seeds = String(argv.seeds ?? '11 22 33 44 55 66').split(/\s+/).filter(Boolean);
const instances = String(argv.instances ?? '').split(/\s+/).filter(Boolean);
const out = argv.out ?? `bench/results/${exp}-${stage}.jsonl`;
const bin = argv.bin ?? 'build/timetable-solve';
const logdir = argv.logdir ?? '';
if (!arms.length || !instances.length) { console.error('need --arm and --instances'); process.exit(2); }
mkdirSync(dirname(out), { recursive: true });
if (logdir) mkdirSync(logdir, { recursive: true });

// Resume: this sandbox is ephemeral and a long batch can be interrupted, so a run already recorded
// for this (exp, stage, arm, instance, seed, budget) is never repeated.
const alreadyDone = new Set();
if (existsSync(out)) {
  for (const line of readFileSync(out, 'utf8').split('\n')) {
    if (!line.trim()) continue;
    try {
      const r = JSON.parse(line);
      alreadyDone.add(`${r.exp}|${r.stage}|${r.arm}|${r.instance}|${r.seed}|${r.timeMs}`);
    } catch { /* a truncated last line from a killed process */ }
  }
}
// A wall-clock ceiling on the batch itself: the driver stops *launching* at the ceiling and lets
// what is running finish, so a batch can be advanced in chunks that each fit inside one tool call.
const stopAfterMin = Number(argv.chunk ?? 0);
const chunkT0 = Date.now();

const cache = new Map();
function archiveOf(p) {
  if (!cache.has(p)) cache.set(p, JSON.parse(gunzipSync(readFileSync(p))));
  return cache.get(p);
}

const jobs = [];
for (const inst of instances) for (const armSpec of arms) for (const seed of seeds) {
  const ci = armSpec.indexOf(':');
  jobs.push({ inst, arm: armSpec.slice(0, ci), flags: armSpec.slice(ci + 1).trim(), seed });
}
// Interleave arms so that any machine drift hits both arms equally.
jobs.sort((a, b) => (a.seed - b.seed) || a.inst.localeCompare(b.inst));
const skipped = jobs.length;
const pending = jobs.filter(j => !alreadyDone.has(
  `${exp}|${stage}|${j.arm}|${basename(j.inst).replace(/\.json\.gz$/, '')}|${Number(j.seed)}|${timeMs}`));
console.log(`${pending.length} of ${skipped} runs still to do`);
jobs.length = 0;
jobs.push(...pending);

let done = 0;
const t0 = Date.now();
function runOne(job) {
  return new Promise(resolve => {
    const tag = `${exp}-${stage}-${basename(job.inst).replace(/\.json\.gz$/, '')}-${job.arm}-${job.seed}`;
    const pl = `/tmp/${tag}.json`;
    const args = ['--instance', job.inst, '--time', String(timeMs), '--threads', String(threads),
                  '--seed', job.seed, '--quiet', '--out', pl];
    if (logdir) args.push('--log', `${logdir}/${tag}.csv`);
    if (job.flags) args.push(...job.flags.split(/\s+/));
    const started = Date.now();
    execFile(bin, args, { maxBuffer: 64 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) { console.error(`FAIL ${tag}: ${stderr || err.message}`); return resolve(); }
      let summary; try { summary = JSON.parse(stdout.trim().split('\n').pop()); }
      catch (e) { console.error(`BADJSON ${tag}`); return resolve(); }
      const archive = archiveOf(job.inst);
      const placements = JSON.parse(readFileSync(pl, 'utf8'));
      const check = validate(archive.problem, placements);
      const rec = {
        ts: new Date().toISOString(), exp, stage, arm: job.arm, flags: job.flags,
        instance: basename(job.inst).replace(/\.json\.gz$/, ''),
        set: job.inst.includes('tight-xl') ? 'tight-xl' : job.inst.includes('tight') ? 'tight'
             : job.inst.includes('xl') ? 'xl' : 'archived',
        n: archive.meta?.nClasses ?? null, seed: Number(job.seed), timeMs, threads,
        wall: (Date.now() - started) / 1000,
        check: { feasible: check.feasible, hard: check.hard, soft: check.soft,
                 objective: check.objective, violations: check.violations, filters: check.filters },
        referenceSoft: archive.hidden ? validate(archive.problem, archive.hidden).soft : null,
        moves: summary.moves, placed: summary.placed, unplaced: summary.unplaced,
        workers: summary.workers,
      };
      appendFileSync(out, JSON.stringify(rec) + '\n');
      done++;
      console.log(`[${done}/${jobs.length} ${((Date.now() - t0) / 60000).toFixed(1)}m] ${tag}` +
                  ` hard=${check.hard} soft=${check.soft} f=${check.objective} moves=${summary.moves}`);
      resolve();
    });
  });
}

const queue = jobs.slice();
async function worker() {
  while (queue.length) {
    if (stopAfterMin > 0 && (Date.now() - chunkT0) / 60000 >= stopAfterMin) break;
    await runOne(queue.shift());
  }
}
await Promise.all(Array.from({ length: par }, worker));
console.log(`${queue.length > 0 ? 'CHUNK-END' : 'DONE'} ${exp}/${stage}: ${done}/${jobs.length} runs, ${queue.length} left, in ${((Date.now() - t0) / 60000).toFixed(1)} min → ${out}`);
