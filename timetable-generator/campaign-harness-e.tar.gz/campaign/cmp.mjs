#!/usr/bin/env node
// Paired comparison of two arms from a results file: per-seed values, medians, paired differences,
// wins/losses, and an exact sign test. Never compares single runs (STUDY.md §1).
import { readFileSync } from 'node:fs';
const [, , file, baseArm, ...testArms] = process.argv;
const rows = readFileSync(file, 'utf8').trim().split('\n').filter(Boolean).map(l => JSON.parse(l));
const med = a => { const s = [...a].sort((x, y) => x - y); const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };
const mean = a => a.reduce((x, y) => x + y, 0) / a.length;
function binomP(k, n) { // two-sided exact sign test
  const C = (n, k) => { let r = 1; for (let i = 0; i < k; i++) r = r * (n - i) / (i + 1); return r; };
  let p = 0; for (let i = 0; i <= n; i++) { const q = C(n, i) / 2 ** n; if (q <= C(n, k) / 2 ** n + 1e-12) p += q; }
  return Math.min(1, p);
}
const keyOf = r => `${r.instance}|${r.seed}`;
const groups = [...new Set(rows.map(r => r.set + ' ' + r.instance + ' t=' + r.timeMs))];
for (const g of groups) {
  const sub = rows.filter(r => (r.set + ' ' + r.instance + ' t=' + r.timeMs) === g);
  const base = new Map(sub.filter(r => r.arm === baseArm).map(r => [keyOf(r), r]));
  if (!base.size) continue;
  console.log(`\n### ${g}   (base: ${baseArm}, n=${base.size} seeds)`);
  const bSoft = [...base.values()].map(r => r.check.soft);
  const bHard = [...base.values()].map(r => r.check.hard);
  console.log(`${baseArm.padEnd(16)} soft ${[...base.values()].sort((a,b)=>a.seed-b.seed).map(r=>r.check.soft).join(' ')}` +
              `  median ${med(bSoft)}  mean ${mean(bSoft).toFixed(2)}  hard ${med(bHard)}`);
  for (const arm of testArms) {
    const t = sub.filter(r => r.arm === arm);
    if (!t.length) continue;
    const pairs = t.filter(r => base.has(keyOf(r))).map(r => ({ seed: r.seed, a: base.get(keyOf(r)), b: r }));
    pairs.sort((x, y) => x.seed - y.seed);
    const soft = pairs.map(p => p.b.check.soft), obj = pairs.map(p => p.b.check.objective);
    const dS = pairs.map(p => p.b.check.soft - p.a.check.soft);
    const dF = pairs.map(p => p.b.check.objective - p.a.check.objective);
    const wins = dS.filter(d => d < 0).length, losses = dS.filter(d => d > 0).length, ties = dS.filter(d => d === 0).length;
    const nEff = wins + losses;
    const bm = mean(pairs.map(p => p.a.check.soft));
    console.log(`${arm.padEnd(16)} soft ${soft.join(' ')}  median ${med(soft)}  mean ${mean(soft).toFixed(2)}` +
      `  Δmean ${(mean(soft) - bm >= 0 ? '+' : '')}${(mean(soft) - bm).toFixed(2)}` +
      ` (${(((mean(soft) - bm) / Math.max(1e-9, bm)) * 100).toFixed(0)}%)` +
      `  W/L/T ${wins}/${losses}/${ties}  p=${nEff ? binomP(Math.min(wins, losses), nEff).toFixed(3) : '-'}` +
      `  Δf_mean ${(mean(dF) >= 0 ? '+' : '')}${mean(dF).toFixed(0)}` +
      `  hard ${med(pairs.map(p => p.b.check.hard))}  moves ${(med(pairs.map(p => p.b.moves)) / 1e6).toFixed(1)}M`);
  }
}
