#!/usr/bin/env bash
# E13 — a direct test of the throughput rule, on the instances where it predicts a null.
#
# §6q's rule says the variable is not the instance set and not the budget, but the residual at the
# moment the clock stops: below ~20 windows the search is at the §3.2 equilibrium and extra
# candidates re-sample a plateau; above it they convert.
#
# That rule was inferred from three points that each varied *two* things at once. This varies one.
# Same instances as the §6p null — tight-XL, the set that decides defaults — same binary, same arms,
# and only the budget moves. Under the rule:
#
#   60 s   residual ~50, still descending  → fast24 should win
#   180 s  residual ~30                    → fast24 should win, by less
#   300 s  residual ~20, at the equilibrium → null, reproducing §6p
#
# A monotone fade across those rungs, on one instance family, is the rule. Anything else falsifies
# it, and the rule is currently the most load-bearing claim in this branch.
#
# THREE arms, not two, after the first pass came back the wrong way (60 s, residual ~30: `fast24`
# lost 5/9, meanD +1.93). `fast24` moves two things at once and only one of them is throughput.
# Cutting the sample from 96 to 24 costs *coverage*, and how much depends on the room domain: on
# tight-XL the mean domain is 134, so 96 sees 72 % of a class's options and 24 sees 18 %, while on
# `instances-unres` ur10 the domain is 582 and the two are 16 % and 4 % — both negligible, leaving
# only throughput. `fast` isolates the throughput half. If `fast` wins at 60 s while `fast24` loses,
# the rule survives and the sample cut is simply wrong at moderate domains. If both lose, the rule is
# wrong and the variable is the room domain, not the residual.
set -u
cd "$(dirname "$0")/.."

log() { printf '[%s] %s\n' "$(date -u +%H:%M:%S)" "$*"; }

MASK="--hoist-day-caps --cap-cache --room-free-mask 2"
FAST="$MASK --room-sample 24"
INST="bench/instances-tight-xl/n12800-s1.json.gz bench/instances-tight-xl/n12800-s2.json.gz bench/instances-tight-xl/n12800-s3.json.gz"

for T in 60000 180000; do
  log "E13-$T: tight-XL, two workers, ${T}ms"
  node campaign/exp.mjs --exp E13-budget --stage "T$T" --time "$T" --threads 2 --par 1 \
    --bin build/ts-I --seeds "11 22 33 44 55 66" --instances "$INST" \
    --arm "off:" --arm "fast:$MASK" --arm "fast24:$FAST" \
    --out bench/results/E13.jsonl 2>&1 | tail -2
done

log "E13 done"
