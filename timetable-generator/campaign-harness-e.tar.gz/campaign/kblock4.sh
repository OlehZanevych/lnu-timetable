#!/usr/bin/env bash
# E8/E9 — the two remaining O(bucket) costs a room scan pays per room.
#
#   E8  hoist MAX_CLASSES_PER_DAY for the class's own lecturers and groups out of the room loop;
#       it is room-independent and was asked once per candidate room.
#   E9  answer the *room's* own cap from a cached per-week bucket count rather than by walking the
#       room's day. That one is per room by nature, so it cannot be hoisted — only made O(1).
#
# E7 showed why both matter: with the clash walk replaced by a mask, the full 582-room scan still
# ran at 2.09 M moves against the shipped 3.55 M, which says something else in the loop is still
# O(bucket) per room. These are the two candidates.
#
# `placementAllowed` is `roomAllows(...) && peopleCapsAllow(...)`, and only the first mentions the
# room. The second walks this class's lecturers' and groups' day buckets and returns the same answer
# for every room in the slot — so `scanBest` asked it 96 times per slot for one answer. The
# people-clash and window costs are hoisted out of that loop already; this one was hidden behind a
# predicate that takes a room argument.
#
# Behaviour-identical by construction, so the arms differ only in how many candidates the same search
# gets through. Measured against E7's best, because the two compose: the hoist removes the
# room-independent cost and the mask removes the room-dependent one.
set -u
cd "$(dirname "$0")/.."

log() { printf '[%s] %s\n' "$(date -u +%H:%M:%S)" "$*"; }

log "build"
cmake --build build --target timetable-solve -j2 2>&1 | tail -3 || exit 1
cp build/timetable-solve build/ts-I || exit 1

log "E8 sanity: neither change may alter what is legal — 60 s, hard=0 and no constraint breaches"
node campaign/exp.mjs --exp E8-smoke --stage S --time 60000 --threads 1 --par 2 \
  --bin build/ts-I --seeds "11" --instances "bench/instances-tight/n03200-s1.json.gz" \
  --arm "off:" --arm "hoist:--hoist-day-caps --cap-cache" \
  --out bench/results/E8-smoke.jsonl 2>&1 | tail -4

INST="bench/instances-unres/uni-ur0-n12800-s1.json.gz bench/instances-unres/uni-ur0-n12800-s2.json.gz bench/instances-unres/uni-ur0-n12800-s3.json.gz bench/instances-unres/uni-ur060-n12800-s1.json.gz bench/instances-unres/uni-ur060-n12800-s2.json.gz bench/instances-unres/uni-ur060-n12800-s3.json.gz bench/instances-unres/uni-ur10-n12800-s1.json.gz bench/instances-unres/uni-ur10-n12800-s2.json.gz bench/instances-unres/uni-ur10-n12800-s3.json.gz"

log "E8-A: the hoist, alone and composed with the mask"
node campaign/exp.mjs --exp E8-hoist --stage A --time 180000 --threads 1 --par 2 \
  --bin build/ts-I --seeds "11 22 33" --instances "$INST" \
  --arm "off:" \
  --arm "hoist:--hoist-day-caps --cap-cache" \
  --arm "allsamp:--hoist-day-caps --cap-cache --room-free-mask 2" \
  --arm "all:--hoist-day-caps --cap-cache --room-free-mask 2 --room-scan-full-below 1024" \
  --out bench/results/E8-A.jsonl 2>&1 | tail -3

log "E8 done"
