#!/usr/bin/env bash
# E11 — the promotion test: does any of this hold where the shipped default lives?
#
# Everything measured in the E7–E10 block was measured on `instances-unres`, a set built to make the
# room dimension bind. That is the right place to *find* an effect and the wrong place to decide
# whether to change a default. The archived and tight-XL sets are what STUDY.md reports, they run at
# two workers, and their classes mostly name a handful of rooms — which is precisely the regime where
# a room-scan fix has the least to offer and the most to break.
#
# Three outcomes, all worth having:
#   wins here too              → promote the defaults.
#   neutral here, wins there   → ship behind flags, and the operational advice of §6k stands.
#   loses here                 → the fix is regime-specific and the default must not move.
#
# Four arms, because E10 turned out to make the two levers **substitutes rather than complements**: the
# cheap scan is worth 21/6 (p = 0.006) on top of the shipped sample of 96 and only 9/7 on top of a
# sample of 24. Twenty-four rooms were never expensive to scan. So `--room-sample 24` alone — a
# one-line default change with no new code behind it — is the leading candidate and has to be on the
# ballot beside the version that also carries three hundred lines of new state.
#
# Two workers and 300 s, because a promotion decision has to be made in the shipped configuration.
set -u
cd "$(dirname "$0")/.."

log() { printf '[%s] %s\n' "$(date -u +%H:%M:%S)" "$*"; }

FAST="--hoist-day-caps --cap-cache --room-free-mask 2"
INST="bench/instances-tight-xl/n12800-s1.json.gz bench/instances-tight-xl/n12800-s2.json.gz bench/instances-tight-xl/n12800-s3.json.gz bench/instances-uni1/uni-f4s0-n12800-s1.json.gz bench/instances-uni1/uni-f4s0-n12800-s2.json.gz bench/instances-uni1/uni-f4s0-n12800-s3.json.gz"

log "E11-C: the shipped sets, two workers, 300 s"
node campaign/exp.mjs --exp E11-promote --stage C --time 300000 --threads 2 --par 1 \
  --bin build/ts-I --seeds "11 22 33" --instances "$INST" \
  --arm "off:" \
  --arm "s24:--room-sample 24" \
  --arm "fast:$FAST" \
  --arm "fast24:$FAST --room-sample 24" \
  --out bench/results/E11-C.jsonl 2>&1 | tail -3

log "E11 done"
