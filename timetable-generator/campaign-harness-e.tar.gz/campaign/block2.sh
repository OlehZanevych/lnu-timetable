#!/usr/bin/env bash
# Waits for the screening batch, then: verifies the region rebuild, probes whether the hard-repair
# trigger fires at a 300 s budget with shipped thresholds, and runs Stage B accordingly.
set -u
cd "$(dirname "$0")/.."
while pgrep -f "exp.mjs --exp B1-screen" > /dev/null; do sleep 20; done
sleep 5
BIN=build/ts-B2
cp build/timetable-solve $BIN

echo "=== region-rebuild verification (correctness + does it fire) ==="
$BIN --instance bench/instances-tight/n06400-s1.json.gz --time 120000 --threads 1 --seed 11 --quiet \
   --hard-repair --hard-repair-after 40000 --hard-repair-kicks 1 --switch-policy 4 \
   --rematch --compaction --parity-moves --out /tmp/rr.json > /tmp/rr.sum 2>&1
python3 - <<'PY'
import json
d = json.load(open('/tmp/rr.sum')); w = d['workers'][0]
print('VERIFY hard=%s soft=%s unplaced=%s HR=%s cleared=%s cert=%s switches=%s regionRebuilds=%s regionClasses=%s'
      % (d['hard'], d['soft'], d['unplaced'], w['hardRepairs'], w['defectsCleared'],
         w['defectsCertified'], w['basinSwitches'], w['regionRebuilds'], w['regionClasses']))
print('SUBSOLVERS ' + ' '.join('%s=%d/%d(cut %d)' % (s['name'], s['won'], s['tried'], s['cut'])
                               for s in w['repairSubsolvers']))
PY

echo "=== trigger probe at 300 s with shipped thresholds ==="
$BIN --instance bench/instances-tight-xl/n12800-s1.json.gz --time 300000 --threads 1 --seed 11 --quiet \
   --hard-repair --rematch --compaction --parity-moves --out /tmp/pr.json > /tmp/pr.sum 2>&1
FIRED=$(python3 -c "import json;d=json.load(open('/tmp/pr.sum'));print(sum(w['hardRepairs'] for w in d['workers']))")
echo "PROBE hardRepairs=$FIRED"
HRFLAGS="--hard-repair --rematch --compaction --parity-moves"
if [ "$FIRED" -lt 2 ]; then
  HRFLAGS="--hard-repair --hard-repair-after 80000 --hard-repair-kicks 2 --rematch --compaction --parity-moves"
  echo "TRIGGER-RELAXED: $HRFLAGS"
fi

echo "=== Stage B: 300 s, six paired seeds, two instances ==="
node campaign/exp.mjs --exp B2-escape --stage B --time 300000 --threads 1 --par 2 --bin $BIN \
  --seeds "11 22 33 44 55 66" \
  --instances "bench/instances-tight-xl/n12800-s1.json.gz ../timetable-ui/scripts/timetable-bench/instances/n12800-s1.json.gz" \
  --arm "off:" \
  --arm "hr1:$HRFLAGS --switch-policy 1" \
  --arm "hr4:$HRFLAGS --switch-policy 4" \
  --arm "tourn:--construct-tournament 3" \
  --arm "adapt:--restart-adaptive" \
  --out bench/results/B2-B.jsonl
echo "BLOCK2 COMPLETE"
