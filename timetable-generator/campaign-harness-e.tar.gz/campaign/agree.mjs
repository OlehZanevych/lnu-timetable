// Stage 0 gate: the C++ evaluator must agree with the independent validator, to the digit,
// on the hidden reference schedule of every archived instance.
import { readFileSync, readdirSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { execFileSync } from 'node:child_process';
import { validate } from '../../timetable-ui/scripts/timetable-bench/validate.mjs';

const dir = process.argv[2] ?? '../timetable-ui/scripts/timetable-bench/instances';
const solver = process.argv[3] ?? 'build/timetable-solve';
let bad = 0, n = 0;
for (const f of readdirSync(dir).filter(x => x.endsWith('.json.gz')).sort()) {
  const path = `${dir}/${f}`;
  const archive = JSON.parse(gunzipSync(readFileSync(path)));
  const ref = validate(archive.problem, archive.hidden);
  const out = JSON.parse(execFileSync(solver, ['--instance', path, '--mode', 'score-hidden'], { encoding: 'utf8' }));
  const v = ref.violations;
  const mine = {
    lecturerConflicts: out.lecturerConflicts, groupConflicts: out.groupConflicts,
    roomConflicts: out.roomConflicts, groupTravel: out.groupTravel,
    lecturerTravel: out.lecturerTravel, abstractRoomOverflow: out.abstractRoomOverflow,
    lecturerWindows: Math.round(out.lecturerWindowHalves / 2),
    groupWindows: Math.round(out.groupWindowHalves / 2),
    mixedOnlineDays: Math.round(out.mixedHalves / 2),
  };
  const diffs = Object.keys(mine).filter(k => mine[k] !== v[k]);
  const objDiff = Math.abs(out.objective - ref.objective) > 0.5;
  n++;
  if (diffs.length || objDiff) {
    bad++;
    console.log(`MISMATCH ${f}: ${diffs.map(k => `${k} cpp=${mine[k]} val=${v[k]}`).join(', ')}` +
                (objDiff ? ` objective cpp=${out.objective} val=${ref.objective}` : ''));
  }
}
console.log(`${n - bad}/${n} archives agree`);
process.exit(bad ? 1 : 0);
