#!/usr/bin/env bash
# K1b/K3: K1-A said the room sample is a pure throughput trade and that *less is more* — 24 rooms
# beat the shipped 96, 256 was worse, and a full scan was catastrophic. Two questions follow.
#
#   K1b  how far down does it go? 8 / 16 / 24 against the shipped 96.
#   K3   is the *travel* evaluation the expensive part? It is the only O(bucket) cost in the room
#        loop, and at six per slot it dominates once the sample itself is small. `--room-travel-budget`
#        moves it directly; `--room-building-first` removes the need for it on the rooms that
#        provably need none.
#
# Run after kblock3.sh. ur0 is included so that a change proposed for the shipped default is measured
# where the shipped default lives, not only where the defect is loudest.
set -u
cd "$(dirname "$0")/.."

log() { printf '[%s] %s\n' "$(date -u +%H:%M:%S)" "$*"; }

INST="bench/instances-unres/uni-ur0-n12800-s1.json.gz bench/instances-unres/uni-ur0-n12800-s2.json.gz bench/instances-unres/uni-ur0-n12800-s3.json.gz bench/instances-unres/uni-ur060-n12800-s1.json.gz bench/instances-unres/uni-ur060-n12800-s2.json.gz bench/instances-unres/uni-ur060-n12800-s3.json.gz bench/instances-unres/uni-ur10-n12800-s1.json.gz bench/instances-unres/uni-ur10-n12800-s2.json.gz bench/instances-unres/uni-ur10-n12800-s3.json.gz"

log "K1b: how far down the sample goes"
node campaign/exp.mjs --exp K1b-sample --stage A --time 180000 --threads 1 --par 2 \
  --bin build/ts-H --seeds "11 22 33" --instances "$INST" \
  --arm "off:" --arm "s8:--room-sample 8" --arm "s16:--room-sample 16" --arm "s24:--room-sample 24" \
  --out bench/results/K1b-A.jsonl 2>&1 | tail -3

log "K3: the travel budget, on top of the best sample K1b found"
node campaign/exp.mjs --exp K3-travel --stage A --time 180000 --threads 1 --par 2 \
  --bin build/ts-H --seeds "11 22 33" --instances "$INST" \
  --arm "s24:--room-sample 24" \
  --arm "s24tb2:--room-sample 24 --room-travel-budget 2" \
  --arm "s24tb24:--room-sample 24 --room-travel-budget 24" \
  --arm "s24bf:--room-sample 24 --room-building-first" \
  --arm "bf:--room-building-first" \
  --out bench/results/K3-A.jsonl 2>&1 | tail -3

log "K block 2 done"
