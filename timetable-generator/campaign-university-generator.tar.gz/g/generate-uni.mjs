#!/usr/bin/env node
// Generates whole-university instances in ONE pass, with cross-faculty coupling as a parameter.
//
// Unlike `compose-university.mjs`, which glues finished faculties together and cannot manufacture
// contention after the fact (CAMPAIGN-LOG.md §6e), this plants the whole university's schedule in a
// single walk of the week. Contention between faculties is therefore present *in the planted
// schedule*, and a perfect answer still provably exists.
//
//   node bench/generate-uni.mjs --out bench/instances-uni1 --sizes "12800" --seeds "1 2 3" \
//        --faculties 4 --service 0.10 --shared-rooms 0.15
import { mkdirSync, writeFileSync } from 'node:fs';
import { gzipSync } from 'node:zlib';
import { emitUniversity } from './emit-uni.mjs';
import { validate } from '../../timetable-ui/scripts/timetable-bench/validate.mjs';

const argv = {};
for (let i = 2; i < process.argv.length; i++) {
  const a = process.argv[i];
  if (!a.startsWith('--')) continue;
  const nx = process.argv[i + 1];
  argv[a.slice(2)] = nx && !nx.startsWith('--') ? (i++, nx) : true;
}
const out = argv.out ?? 'bench/instances-uni1';
const sizes = String(argv.sizes ?? '12800').split(/\s+/).filter(Boolean).map(Number);
const seeds = String(argv.seeds ?? '1').split(/\s+/).filter(Boolean).map(Number);
const opts = {
  faculties: Number(argv.faculties ?? 4),
  serviceShare: Number(argv.service ?? 0.10),
  sharedRoomShare: Number(argv['shared-rooms'] ?? 0.15),
  ...(argv.opts ? JSON.parse(argv.opts) : {}),
};
const tag = argv.tag ?? `f${opts.faculties}s${String(opts.serviceShare).replace('.', '')}`;
mkdirSync(out, { recursive: true });

const index = [];
for (const n of sizes) {
  for (const seed of seeds) {
    const t0 = Date.now();
    const { problem, hidden, meta } = emitUniversity(n, seed, opts);
    const ref = validate(problem, hidden);
    const name = `uni-${tag}-n${String(n).padStart(5, '0')}-s${seed}`;
    if (ref.hard !== 0) {
      console.error(`${name}: REJECTED — planted schedule has ${ref.hard} hard violations ` +
                    JSON.stringify(ref.violations));
      process.exitCode = 1;
      continue;
    }
    writeFileSync(`${out}/${name}.json.gz`,
                  gzipSync(Buffer.from(JSON.stringify({ meta: { ...meta, ...opts }, problem, hidden }))));
    index.push({ file: `${name}.json.gz`, ...meta, ...opts, referenceSoft: ref.soft });
    console.log(`${name}: ${meta.requirements} req, ${meta.lecturers} lecturers, ${meta.rooms} rooms, ` +
                `faculties=${opts.faculties} service=${opts.serviceShare} sharedRooms=${opts.sharedRoomShare} ` +
                `— hidden hard=0 soft=${ref.soft} — ${Date.now() - t0} ms`);
  }
}
writeFileSync(`${out}/index.json`, JSON.stringify(index, null, 1));
